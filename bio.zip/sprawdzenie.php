﻿Połączyłem się
<h1>Użytkownik już istnieje!</h1><html>
<head>
<form action="nowyUzytkownikTest.php" method="POST">
   <span id="label"> Witaj &nbsp  </span>
   <input type="text" name='nazwaUzytkownika' value='' readonly ></input>
    <div class="polecenie">
			<p> Na wykonanie tego zadania masz jedną minutę. Jeśli będziesz gotowy wciśnij JESTEM GOTOWY - pojawi się wtedy plansza. Powodzenia! Czas liczony od mementu wciśnięcia przycisku START.
			<br></><br></><br></><br></>
			</p>
		</div>
   <button type="submit" value="Send" name="submit" id="submit">JESTEM GOTOWY!</button>
 
</form>
<style type="text/css">

body {
background-image: url('tlo.png');
 background-repeat:no-repeat;
     background-position: center center;
    background-attachment: fixed;
    background-size: cover;
}
#submit{
	width: 10%;
margin-left: 45%;
margin-right: 45%

}
</style>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
</head>
<body>
</body>
</html>

