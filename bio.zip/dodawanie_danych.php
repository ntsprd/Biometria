﻿Połączyłem się<h2> Do tabeli dodano następujące dane:</h2><br>
	<b>Nazwa użytkownika:</b>&nbsp;<i></i><br>
	<b>Ilość wpisanych znaków:</b>&nbsp;<i></i><br>
	<b>Ilość popełnionych błędów:</b>&nbsp;<i></i><br>
	<b>Ilość poprawnie wpisanych danych:</b>&nbsp;<i></i><br>
	<b>Wyniki:</b>&nbsp;<i></i><br><html>
<head>
<style type="text/css">

body {
background-image: url('tlo.png');
 background-repeat:no-repeat;
     background-position: center center;
    background-attachment: fixed;
    background-size: cover;
}
</style>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"  />
<a href="strona_tytulowa.html">Teraz masz szansę się zidentyfikować ;) </a>
</head>
<body>
</body>
</html>