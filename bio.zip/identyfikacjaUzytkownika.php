﻿Połączyłem się
JesteśBartek<html>
<head>

</form>
<style type="text/css">

body {
background-image: url('tlo.png');
 background-repeat:no-repeat;
     background-position: center center;
    background-attachment: fixed;
    background-size: cover;
}
#submit{
	width: 10%;
margin-left: 45%;
margin-right: 45%

}
</style>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
</head>
<body>
</body>
</html>