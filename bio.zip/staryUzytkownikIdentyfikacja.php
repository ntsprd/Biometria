
<html>
<head>

<meta charset="UTF-8">
	<title>System biometryczny identyfikujący/weryfikujący na podstawie charakterystyki używania klawiatury</title>
	<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
	<div id="ramka">
			
		
		<span class="odpowiedzi" id="odpowiedzi">
			<span id="label"> Czas (w sekundach): &nbsp  </span>
			<span id="inputCzas" disabled>&nbsp&nbsp</span>
			    <form action ="identyfikacjaUzytkownika.php " method="post">
				<span id="label"> Nazwa użytkownika:  &nbsp      </span>
				<input type="text" id="nazwaUzytkownika" name="nazwaUzytkownika"  value="" readonly></input>
				
				
				<span id="label"> Ilość wpisanych znaków:  &nbsp      </span>

				<input type="text" id="inputZnaki" name="inputZnaki" readonly >&nbsp&nbsp</input>
				<span id="label"> &nbsp&nbsp Ilość popełnionych błędów:  &nbsp  </span>
			
				<input type="text" id="inputBledy"  name="inputBledy"  readonly>&nbsp&nbsp </input>
				<span id="label"> Ilość poprawnie wpisanych znaków: &nbsp </span>
			
				<input type="text" id="inputPoprawneZnaki" name="inputPoprawneZnaki" readonly> &nbsp&nbsp </input>
				
			    <input type="text" id="inputWyniki" name="inputWyniki" hidden> &nbsp&nbsp </input>
			
			<input type=submit id="dodajDane" value="dodaj dane" hidden ></input>
			</form>
		</span>
		
		 <button id="start" onClick="document.getElementById('tekst').style.display='block';document.getElementById('start').style.display='none';odliczaj(document.getElementById('sekundy'),5)">START</button></ br>
			<div id="tekst" style="display: none" >
		    		<span id="sekundy"></span>
	
					<div id="tresc" style="display:none;">
						 <p>Biometria wykorzystywana jest przede wszystkim jako sposób kontroli dostępu do chronionych pomieszczeń lub autoryzacji użytkowników korzystających z określonych danych, programów czy urządzeń. Podstawową jej funkcją jest więc uniemożliwianie realizacji nieautoryzowanego dostępu do bankomatów, komputerów osobistych, sieci komputerowych, telefonów komórkowych, domowych systemów alarmowych, zamków drzwiowych, kart procesorowych itp. Ponadto w obiektach użyteczności publicznej i firmach, systemy biometryczne wspomagają wyszukiwanie miejsca pobytu wybranych osób oraz rejestrację czasu pracy. </p>
					    <input type="text" id="input" size="500" onkeydown ="KeyPress(event);" onkeypress="validatePassword(this, event);"
					   /> 
  				
						    
						
 						
						
				</div>
			</div>
	</div>
</body>

</html>
<script>

    				o=document.getElementById('sekundy')
							p=document.getElementById('inputCzas')
							function odliczaj(o,sek){
								o.innerHTML=sek
									if(sek>0)setTimeout(function(){odliczaj(o,--sek)},1e3)
									if (sek == 0)
								{
								div = document.getElementById('tresc');
								div.style.display = 'block';
								sec = document.getElementById('sekundy');
								sec.style.display = 'none';
								odliczaj2(document.getElementById('inputCzas'),60)
					            
								}
							}
							

							function odliczaj2(p,sek2){
								p.innerHTML=sek2
									if(sek2>0)setTimeout(function(){odliczaj2(p,--sek2)},1e3)
									if (sek2 == 0)
								{
							
							    //window.location.href = "dodawanie_danych.php ";
								var button = document.getElementById("dodajDane");
								button.form.submit();
								}
							}
								
    var litery = 0;
    var bledy = 0;
    var poprawneLitery = 0;
	

    function KeyPress(event){
     
   			if (event.which == 8 || event.which == 46 ){
   			 event.preventDefault();
   			}	
   			//else if (event.ctrlKey){
   				//event.preventDefault();
   			//}
    }
	function validatePassword(w, event){
		var tekstBiometria = "Biometria wykorzystywana jest przede wszystkim jako sposób kontroli dostępu do chronionych pomieszczeń lub autoryzacji użytkowników korzystających z określonych danych, programów czy urządzeń. Podstawową jej funkcją jest więc uniemożliwianie realizacji nieautoryzowanego dostępu do bankomatów, komputerów osobistych, sieci komputerowych, telefonów komórkowych, domowych systemów alarmowych, zamków drzwiowych, kart procesorowych itp. Ponadto w obiektach użyteczności publicznej i firmach, systemy biometryczne wspomagają wyszukiwanie miejsca pobytu wybranych osób oraz rejestrację czasu pracy" ;
         
  		   
  			if (tekstBiometria[poprawneLitery] == String.fromCharCode(event.keyCode) ) {
  				 //alert("kod: " + event.keyCode+"litera: " + String.fromCharCode(event.keyCode));
  				 poprawneLitery++;
  				 document.getElementById("inputPoprawneZnaki").value = poprawneLitery;

  			} else {
  				 //alert("DUPA ");
  				 event.preventDefault();
  				 bledy++;
  				 document.getElementById("inputBledy").value = bledy;
  			}
  			litery++;
			
  			document.getElementById("inputZnaki").value = litery;
			if ( document.getElementById("inputBledy").value == ""){
				document.getElementById("inputWyniki").value = poprawneLitery;
				}else{
			document.getElementById("inputWyniki").value = (poprawneLitery/litery) * (poprawneLitery/bledy);
				}
  }
  
	
  
  


</script>

